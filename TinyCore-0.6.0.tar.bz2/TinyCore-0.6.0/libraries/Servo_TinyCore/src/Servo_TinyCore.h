/*
  Servo_TinyCore.h - Interrupt driven Servo library for Arduino using 16 bit timers- Version 2
  Copyright (c) 2009 Michael Margolis.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
  A servo is activated by creating an instance of the Servo class passing
  the desired pin to the attach() method.
  The servos are pulsed in the background using the value most recently
  written using the write() method.

  Note that analogWrite of PWM on pins associated with the timer are
  disabled when the first servo is attached.
  Timers are seized as needed in groups of 12 servos - 24 servos use two
  timers, 48 servos will use four.
  The sequence used to seize timers is defined in timers.h

  The methods are:

    Servo - Class for manipulating servo motors connected to Arduino pins.

    attach(pin )  - Attaches a servo motor to an i/o pin.
    attach(pin, min, max  ) - Attaches to a pin setting min and max values in microseconds
    default min is 544, max is 2400

    write()     - Sets the servo angle in degrees.  (invalid angle that is valid as pulse in microseconds is treated as microseconds)
    writeMicroseconds() - Sets the servo pulse width in microseconds
    read()      - Gets the last written servo pulse width as an angle between 0 and 180.
    readMicroseconds()   - Gets the last written servo pulse width in microseconds. (was read_us() in first release)
    attached()  - Returns true if there is a servo attached.
    detach()    - Stops an attached servos from pulsing its i/o pin.
 */

#ifndef Servo_h
#define Servo_h

#include <inttypes.h>

/*
 * Defines for 16 bit timers used with  Servo library
 *
 * If _useTimerX is defined then TimerX is a 16 bit timer on the current board
 * timer16_Sequence_t enumerates the sequence that the timers should be allocated
 * _Nbr_16timers indicates how many 16 bit timers are available.
 */
#if (defined(__AVR_ATtiny43__))
#error "The Servo library does not support the ATtiny43"

#elif (defined(__AVR_ATtinyX5__) || defined (__AVR_ATtinyX61__))


#define Servo_VERSION           2     // software version of this library
#ifndef MIN_PULSE_WIDTH               // Let the user set min/max pulse lengths
#if (F_CPU==16500000L)
#define MIN_PULSE_WIDTH       561     // 1/32nd longer
#else
#define MIN_PULSE_WIDTH       544     // the shortest pulse sent to a servo
#endif
#endif
#ifndef MAX_PULSE_WIDTH               // Let the user set min/max pulse lengths
#if (F_CPU==16500000L)
#define MAX_PULSE_WIDTH      2475     // 1/32nd longer
#else
#define MAX_PULSE_WIDTH      2400     // the longest pulse sent to a servo
#endif
#endif
#define MAX_SERVOS              5
#define INVALID_SERVO         255

class Servo
{
public:
  Servo();
  ~Servo();
  uint8_t attach(uint8_t pin);              // attach the given pin to the next free channel, returns channel number or 0 if failure
  uint8_t attach(uint8_t pin, uint16_t newMin, uint16_t newMax); // as above but also sets min and max values for writes.
  void detach();

  void write(uint16_t value);               // if value is < 200 its treated as an angle, otherwise as pulse width in microseconds
  void writeMicroseconds(uint16_t value);   // Write pulse width in microseconds
  uint16_t read();                          // returns current pulse width as an angle between 0 and 180 degrees
  uint16_t readMicroseconds();              // returns current pulse width in microseconds for this servo
  bool attached();                          // return true if this servo is attached, otherwise false

private:

   //private variables
   uint8_t  servoIndex;                  // Our ID number that we get from the ServoSequencer after we register with it
   uint16_t min;                          // minimum pulse length that corresponds to the angle of 0 degrees
   uint16_t max;                          // maximum pulse length that corresponds to the angle of 180 degrees

   //our own map function, so that we don't have to get it from some library
};


#else

#include "avr/ServoTimers.h"

#define Servo_VERSION           2     // software version of this library

#ifndef MIN_PULSE_WIDTH               // Let the user set min/max pulse lengths
#define MIN_PULSE_WIDTH       544     // the shortest pulse sent to a servo
#endif
#ifndef MAX_PULSE_WIDTH               // Let the user set min/max pulse lengths
#define MAX_PULSE_WIDTH      2400     // the longest pulse sent to a servo
#endif
#define DEFAULT_PULSE_WIDTH  1500     // default pulse width when servo is attached
#define REFRESH_INTERVAL    20000     // minumim time to refresh servos in microseconds

#define SERVOS_PER_TIMER       12     // the maximum number of servos controlled by one timer
#define MAX_SERVOS   (_Nbr_16timers  * SERVOS_PER_TIMER)

#define INVALID_SERVO         255     // flag indicating an invalid servo index

typedef struct  {
  uint8_t nbr        :6 ;             // a pin number from 0 to 63
  uint8_t isActive   :1 ;             // true if this channel is enabled, pin not pulsed if false
} ServoPin_t   ;

typedef struct {
  ServoPin_t Pin;
  volatile unsigned int ticks;
} servo_t;

class Servo
{
public:
  Servo();
  uint8_t attach(int pin);           // attach the given pin to the next free channel, sets pinMode, returns channel number or 0 if failure
  uint8_t attach(int pin, int min, int max); // as above but also sets min and max values for writes.
  void detach();
  void write(int value);             // if value is < 200 its treated as an angle, otherwise as pulse width in microseconds
  void writeMicroseconds(int value); // Write pulse width in microseconds
  int read();                        // returns current pulse width as an angle between 0 and 180 degrees
  int readMicroseconds();            // returns current pulse width in microseconds for this servo (was read_us() in first release)
  bool attached();                   // return true if this servo is attached, otherwise false
private:
   uint8_t servoIndex;               // index into the channel data for this servo
   int8_t min;                       // minimum is this value times 4 added to MIN_PULSE_WIDTH
   int8_t max;                       // maximum is this value times 4 added to MAX_PULSE_WIDTH
};
#endif //end of non-8-bit avr servo header

#endif
