# ATtiny25/45/85

The ATtiny25/45/85 family is arguably the most popular classic tinyAVR series, widely used in small and space-constrained designs. Available in an 8-pin DIP, SOIC-8 and QFN-20 packages, these parts pack a USI peripheral, a differential ADC, an on-chip PLL, and a high-speed Timer1 into a minimal footprint. The three family members differ only in flash and RAM size: 2/4/8 KiB of flash and 128/256/512 bytes of RAM respectively. They do not feature a hardware UART; serial communication relies on the built-in software serial implementation.

| Pinout diagram                       | Digispark                                       | Minimal setup schematic                                 |
|--------------------------------------|-------------------------------------------------|---------------------------------------------------------|
|<img src="Pinout_x5.png" width="300"> | <img src="Pinout_x5_Digispark.png" width="360"> |<img src="ATtiny25_45_85_minimal_setup.png" width="240"> |

## Table of contents
- [Specifications](#specifications)
- [Urboot bootloader](#urboot-bootloader)
- [Micronucleus bootloader](#urboot-bootloader)
- [LED_BUILTIN is on PB2](#led_builtin-is-on-pb2)
- [Internal oscillator calibration](#internal-oscillator-calibration)
- [Features](#features)
  - [PLL clock](#pll-clock)
  - [Timer1 is a high speed timer](#timer1-is-a-high-speed-timer)
  - [PWM](#pwm)
  - [PWM frequency](#pwm-frequency)
  - [I2C support](#i2c-support)
  - [SPI support](#spi-support)
  - [UART (Serial) support](#uart-serial-support)
  - [Tone support](#tone-support)
  - [Servo support](#servo-support)
  - [Servo and tone conflicts](#servo-and-tone-conflicts)
- [ADC features](#adc-features)
  - [ADC reference options](#adc-reference-options)
  - [Internal sources](#internal-sources)
  - [Differential channels](#differential-channels)
  - [Temperature measurement](#temperature-measurement)

### Specifications

| Specification                              | ATtiny25/45/85         |
|--------------------------------------------|------------------------|
| Bootloader (occupies 256 / 1400 bytes)     | Urboot / Micronucleus  |
| Flash available (no bootloader)            | 2048/4096/8192 bytes   |
| Flash available (with Urboot bootloader)   | 1792/3840/7936 bytes   |
| Flash available (with Micronucleus bootl.) | 640/2688/6784 bytes    |
| RAM                                        | 128/256/512 bytes      |
| EEPROM                                     | 128/256/512 bytes      |
| GPIO Pins                                  | 5 + RESET              |
| ADC Channels                               | 4 (incl RST)           |
| Differential ADC                           | 1x/20x gain            |
| PWM Channels                               | 3                      |
| Interfaces                                 | USI                    |
| Int. Oscillator or PLL (MHz)               | 16, 8, 4, 2, 1         |
| External Crystal                           | All standard           |
| External Clock                             | All standard           |
| Int. WDT Oscillator                        | 128 kHz                |
| LED_BUILTIN                                | PIN_PB2                |

### Urboot bootloader
This core uses the [Urboot bootloader](https://github.com/stefanrueger/urboot/) for the ATtiny25/45/85, a modern replacement that addresses the fundamental shortcomings of Optiboot on these parts. The bootloader is configured to occupy only *256 bytes*, less than half of what Optiboot required, leaving 1792, 3840, or 7936 bytes available for user code on the ATtiny25, 45, and 85 respectively. Urboot can be reconfigured to include additional features at the cost of increased flash usage, though the 256-byte variant used here covers the needs of most users. These chips does not have a hardware serial port, so Urboot is configured to use software-based UART.

A critical improvement over Optiboot is that Urboot actively protects both itself and the reset vector from being overwritten during flash operations, preventing the bootloader from bricking itself. The bootloader remains intact regardless of what is uploaded, making it a reliable choice.

No pre-compiled bootloader binaries are distributed with this core, instead, Avrdude generates the appropriate bootloader on the fly during upload.
The default serial upload pins for these chips are PB0 (TX) and PB1 (RX). The WDT timeout, UART pins, baud rate, and other bootloader parameters can be customized by editing the relevant entries in boards.txt or in your platformio.ini project configuration file.

The AVR internal oscillator is neither highly accurate nor necessarily tightly calibrated from the factory. Since a stable system clock is essential for asynchronous protocols such as UART, the bootloader can be configured to apply an oscillator correction factor. This is exposed as a Tools menu option, with adjustable compensation ranging from -5.00% to +5.00%.

### Micronucleus bootloader
[Micronucleus](https://github.com/micronucleus/micronucleus) is a bootloader that emulates a USB interface and lets you upload sketches using a native USB interface without the need for an external programmer or USB-to-serial adapter. TinyCore implements the V2.6 of this bootloader.

Rather than relying on a hardware USB controller, Micronucleus uses **V-USB**, a software-only implementation of the USB 1.1 low-speed protocol using the ATtiny's I/O pins. On the ATtiny25/45/85, two pins are dedicated to the USB data lines (D+ and D-), typically with small series resistors and zener diodes for voltage clamping to meet USB signal level requirements.

When the microcontroller powers up or is reset, Micronucleus briefly enumerates as a USB device and waits a few seconds for an upload command from the host. If no upload is initiated, it jumps to the user application. If an upload is detected, it receives the new sketch, writes it to flash, and then starts it. The newest version of Micronucleus occupies about **1400 bytes** of flash, compared to 256 bytes for Urboot. Note that the microcontroller will be running from its 16 MHz internal PLL when using the Micronucleus bootloader.

The most well-known board using Micronucleus on the ATtiny85 is the **Digispark**, a tiny development board with a built-in USB connector (or USB pins broken out), a voltage regulator, and a few GPIO pins. It was originally designed by Digistump and has since been widely cloned and sold cheaply on sites like AliExpress. The **ATtiny88**-based **MH-Tiny** board follows the same concept for a slightly larger chip.

#### Uploading using the Micronucleus bootloader
To upload sketches to a board that already has the Micronucleus bootloader installed (for instance, the Digispark), select *Tools > Bootloader > Original Micronucleus (16 MHz PLL)* in the Arduino IDE. Unplug the board from your computer, click *Upload*, and connect the board to your computer when Avrdude tells you to. The sketch will start automatically when the upload is done.

#### Upgrading the bootloader

Because the most recent version of Micronucleus is much more memory efficient than the older versions, it is advisable to upgrade the bootloader.

The bootloader itself can be upgraded over USB using the Micronucleus tool with a special "upgrade" firmware, as long as the chip is already running the Micronucleus bootloader. Select *Tools > Bootloader > Upgrade to newest Micronucleus (16 MHz PLL)*. In order to get Arduino IDE to play along, select *Tools > Programmers* and select any programmer. Unplug the board from the computer and click *Burn Bootloader*. Connect the board to your computer when Avrdude tells you to. When the upload process is finished, give the microcontroller a little time to reprogram itself. The board should now be ready!

#### Flashing the bootloader using a programmer
A chip without any bootloader will require an ISP programmer for the initial flash. Select *Tools > Bootloader > New Micronucleus (16 MHz PLL)*, and select your preferred programmer under *Tools > Programmer*. Connect the ISP programmer to the target microcontroller and click *Burn Bootloader*.

### LED_BUILTIN is on PB2
This is different than on ATtinyCore, which uses PB1.

### Internal oscillator calibration
The internal 8 MHz oscillator and 16 MHz PLL is not highly accurate, which is acceptable for many applications but insufficient for asynchronous protocols such as UART, where a frequency error of ±3-4% will cause communication to fail.

To address this, TinyCore provides an [Oscillator calibration sketch](../libraries/TinyCore/examples/OscillatorCalibration/OscillatorCalibration.ino) that calculates a corrected OSCCAL value based on characters received over UART. It uses the default UART pins, **TX = PB0** and **RX = PB1**. Before uploading the sketch, ensure the target is running from its internal 8 MHz oscillator or 16 MHz PLL, and EEPROM preservation is enabled. Once uploaded, open the serial monitor at 115200 baud, select "No line ending", and repeatedly send the character `x`. After a few attempts, readable text should begin to appear in the serial monitor. Once the calibration value has stabilised, it is automatically stored in the last byte of EEPROM for future use. This value is not loaded automatically and must be applied explicitly in your sketch:

```cpp
  // Check if there exists any OSCCAL value in the last EEPROM byte
  // If not, run the oscillator tuner sketch first
  uint8_t cal = EEPROM.read(E2END);
  if (cal < 0xff)
    OSCCAL = cal;
```

Another approach is to use the [avrCalibrate](https://github.com/felias-fogg/avrCalibrate) library, which uses a host microcontroller along with the target to perform the calibraion. avrCalibrate can also calibrate internal voltage references.


## Features

### PLL clock
The ATtiny25/45/85 features an on-chip PLL clocked from the internal oscillator, running at a nominal frequency of 64 MHz when enabled. It can be used in two ways, either independently or in combination.  
The system clock can be derived from one quarter of the PLL output, providing a 16 MHz clock source without an external crystal. This option inherits the accuracy limitations of the internal oscillator driving the PLL. Timer1 can be clocked directly from the PLL, enabling high-speed PWM and other timer functions independent of the system clock speed.

### Timer1 is a high speed timer
See the [TinyCore library](../libraries/TinyCore/README.md)

### PWM
The core configures PWM output as follows.
Timer0 is a standard 8-bit timer, consistent with most classic AVR devices. It provides PWM output on PB0 and PB1 with independent duty cycles.

Timer1 is a more capable but also more complex timer. By default it is clocked from the main peripheral clock (`F_CPU`), but it can be reconfigured to use the on-chip PLL via the included [TinyCore library](../libraries/TinyCore/README.md). The PLL derives its clock from the internal oscillator multiplied by a factor of 8, yielding a nominal frequency of 64 MHz.

Inverted PWM outputs are not supported by the core, as the hardware provides no means to enable an inverted output independently of its corresponding non-inverted output. If inverted output is required, it must be configured manually via direct register writes. Note that calling `digitalWrite()` or `analogWrite()` on any pin associated with a manually configured timer may interfere with that configuration and should be avoided.

### PWM frequency
TC0 is always run in Fast PWM mode: We use TC0 for millis, and phase correct mode can't be used on the millis timer - you need to read the count to get micros, but that doesn't tell you the time in phase correct mode because you don't know if it's upcounting or downcounting in phase correct mode. TC1 has no phase correct mode. However because of the flexible prescaler, we can always keep the output from TC1 between 488 and 977 Hz, our target range.

| F_CPU  | F_PWM<sub>TC0</sub> | F_PWM<sub>TC1</sub>   | Notes                        |
|--------|---------------------|-----------------------|------------------------------|
| 1  MHz | 1/8/256=     488 Hz |  1/8/256=      488 Hz |                              |
| 2  MHz | 2/8/256=     977 Hz |  2/16/256=     488 Hz |                              |
| <4 MHz | x/8/256= 488 * x Hz |  x/16/256= 244 * x Hz |                              |
| 4  MHz | 4/8/256=    1960 Hz |  4/16/256=     977 Hz |                              |
| <8 MHz | x/64/256= 61 * x Hz |  x/32/256= 122 * x Hz |                              |
| 8  MHz | 8/64/256=    488 Hz |  8/64/256=     488 Hz |                              |
| >8 MHz | x/64/256= 61 * x Hz |  x/64/256=  61 * x Hz |                              |
| 12 MHz | 12/64/256=   735 Hz | 12/64/256=     735 Hz |                              |
| 16 MHz | 16/64/256=   977 Hz | 16/64/256=     977 Hz |                              |
|>16 MHz | x/64/256= 61 * x Hz | x/128/256=  31 * x Hz |                              |
| 20 MHz | 20/64/256=  1220 Hz | 20/128/256=    610 Hz |                              |

Where speeds above or below a certain speed are specified, it's implied that the other end of the range is the next marked value. So >16 in that table is for 16-20 MHz clocks. The formula is given as a constant times x where x is expressed as MHz (the division above gets the time in megahertz - in the interest of readability I did not include the MHz to Hz conversion - I'm sure you all know how to multiply by a million)
For more information see the [Changing PWM Frequency](Ref_ChangePWMFreq.md) reference.

### I2C support
The ATtiny25/45/85 does not feature a dedicated I2C peripheral. Instead, I2C functionality is implemented through the hardware USI (Universal Serial Interface), exposed transparently via the Wire library included with this core. **External pull-up resistors are required on the SDA and SCL lines for I2C to function**.

Only the built-in Wire library is officially supported. Issues arising from the use of third-party I2C libraries should be directed to the respective library's author or maintainer, as compatibility with USI-based implementations cannot be guaranteed.

### SPI support
The ATtiny25/45/85 does not feature a dedicated SPI peripheral. Instead, SPI functionality is implemented through the hardware USI (Universal Serial Interface), exposed transparently via the included SPI library.
Note that the USI uses DI (Data In) and DO (Data Out) rather than the conventional MISO/MOSI naming. The mapping depends on the operating mode: in master mode, DI corresponds to MISO and DO to MOSI; in slave mode, these are reversed. The MISO and MOSI #defines reflect master mode, as this is by far the most common use case and the only mode supported by the SPI library.

Only the built-in SPI library is officially supported. If you encounter issues when using a third-party SPI library, please contact that library's author or maintainer, compatibility with USI-based hardware is their responsibility.

### UART (Serial) support
The ATtiny25/45/85 does not feature a hardware UART. When operating from the internal oscillator, clock calibration may be necessary to achieve sufficient timing accuracy for reliable UART communication.

The core provides a built-in software serial implementation exposed as `Serial`. To avoid conflicts with libraries and applications that rely on pin change interrupts (PCINTs), it uses the analog comparator pins and their dedicated interrupt. The default pin assignment is AIN0 for TX and AIN1 for RX.

Being a software implementation, `Serial` cannot transmit and receive simultaneously. The `SoftwareSerial` library may be used alongside the built-in `Serial`, but the same half-duplex limitation applies, only one channel across both instances can be active at a time. If simultaneous TX/RX or the use of multiple serial interfaces is required, a device with a hardware UART should be used instead. Note that software serial has both an [upper and a lower baud rate limit](Ref_TinySoftSerial.md).

The TX pin can be reassigned to any pin using `Serial.setTxBit(n)`, where n corresponds to the pin number in PBn notation. To disable the RX channel and use TX only, select TX only from the Software Serial menu under Tools. To disable TX, refrain from printing to Serial and configure the pin to the desired mode after calling `Serial.begin()`.

### Tone support
`tone()` is implemented using Timer1. If Timer1 has been configured for high-speed operation, `tone()` will produce frequencies two or four times higher than expected, normal speed operation is recommended when using `tone()`.

For best results, use pin 1 or 4 as the tone output pin. On these pins, `tone()` drives Timer1's output compare unit directly rather than toggling the pin via interrupt, which extends the usable frequency range into the MHz region. When `SoftwareSerial` or the built-in `Serial` is active, `tone()` remains functional on pins 1 and 4 but is unavailable on all other pins. Note that `tone()` disables PWM on pins 1 and 4 for the duration of its use.

### Servo support
A built-in Servo library is included with this core, with full support for the ATtiny25/45/85. Note that any ongoing software serial activity, whether through `SoftwareSerial` or the built-in `Serial`, will cause glitches in the servo signal during transmission or reception.

### Servo and tone conflicts
The Servo library and `tone()` both require exclusive control of Timer1, which has two important consequences. PWM is unavailable on the Timer1 pins (PB4 and, by default, PB1) whenever `tone()` is active or the Servo library is in use. Additionally, the Servo library and `tone()` cannot be used simultaneously.

## ADC features
The ATtiny25/45/85 has a differential ADC. Gain of 1x or 20x is available, and two differential pairs are available. The ADC supports both bipolar mode (-512 to 511) and unipolar mode (0-1023) when taking differential measurements; you can set this using `setADCBipolarMode(true or false)`.

### ADC reference options
The ATtiny25/45/85 has both the 1.1V and 2.56V reference options, a rarity among the classic tinyAVR parts. It even supports an external reference, not that you can usually spare the pins to use one.

| Reference option   | Reference voltage           | Uses AREF pin        | Aliases/synonyms                         |
|--------------------|-----------------------------|----------------------|------------------------------------------|
| `DEFAULT`          | Vcc                         | No, pin available    |                                          |
| `EXTERNAL`         | Voltage applied to AREF pin | Yes, ext. voltage    |                                          |
| `INTERNAL1V1`      | Internal 1.1V reference     | No, pin available    | `INTERNAL`                               |
| `INTERNAL2V56`     | Internal 2.56V reference    | No, pin available    | `INTERNAL2V56_NO_CAP` `INTERNAL2V56NOBP` |
| `INTERNAL2V56_CAP` | Internal 2.56V reference    | Yes, w/cap. on AREF  |                                          |

### Internal sources
| Voltage Source  | Description                            |
|-----------------|----------------------------------------|
| ADC_INTERNAL1V1 | Reads the INTERNAL1V1 reference        |
| ADC_GROUND      | Measures ground (offset cal?)          |
| ADC_TEMPERATURE | Internal temperature sensor            |

### Differential channels
The ADC can act as a differential ADC with selectable 1x or 20x gain. It can operate in either unipolar or bipolar mode, and the polarity of the two differential pairs can be inverted in order to maximize the resolution available in unipolar mode. TinyCore wraps the IPR bit into the name of the differential ADC channel. Note the organization of the channels - there are two differential pairs A0/A1, and A2/A3 - but there is no way to take a differential measurement between A0 and A2 or A3 for example.

| Positive   | Negative   |Gain | Name            | Notes            |
|------------|------------|-----|-----------------|------------------|
| ADC0 (PB5) | ADC0 (PB5) | 1x  | DIFF_A0_A0_1X   | For offset cal.  |
| ADC0 (PB5) | ADC0 (PB5) | 20x | DIFF_A0_A0_20X  | For offset cal.  |
| ADC0 (PB5) | ADC1 (PB2) | 1x  | DIFF_A0_A1_1X   |                  |
| ADC0 (PB5) | ADC1 (PB2) | 20x | DIFF_A0_A1_20X  |                  |
| ADC1 (PB2) | ADC0 (PB5) | 1x  | DIFF_A1_A0_1X   | Input Reversed   |
| ADC1 (PB2) | ADC0 (PB5) | 20x | DIFF_A1_A0_20X  | Input Reversed   |
| ADC2 (PB4) | ADC2 (PB4) | 1x  | DIFF_A2_A2_1X   | For offset cal.  |
| ADC2 (PB4) | ADC2 (PB4) | 20x | DIFF_A2_A2_20X  | For offset cal.  |
| ADC2 (PB4) | ADC3 (PB3) | 1x  | DIFF_A2_A3_1X   |                  |
| ADC2 (PB4) | ADC3 (PB3) | 20x | DIFF_A2_A3_20X  |                  |
| ADC3 (PB3) | ADC2 (PB4) | 1x  | DIFF_A3_A2_1X   | Input Reversed   |
| ADC3 (PB3) | ADC2 (PB4) | 20x | DIFF_A3_A2_20X  | Input Reversed   |

### Temperature measurement
To measure the temperature, select the 1.1v internal voltage reference, and `analogRead(ADC_TEMPERATURE)`; This value changes by approximately 1 LSB per degree C. This requires calibration on a per-chip basis to translate to an actual temperature, as the offset is not tightly controlled - take the measurement at a known temperature (we recommend 25C - though it should be close to the nominal operating temperature, since the closer to the single point calibration temperature the measured temperature is, the more accurate that calibration will be without doing a more complicated two-point calibration (which would also give an approximate value for the slope)) and store it in EEPROM (make sure that `EESAVE` fuse is set first, otherwise it will be lost when new code is uploaded via ISP) if programming via ISP, or at the end of the flash if programming via a bootloader (same area where oscillator tuning values are stored). See the section below for the recommended locations for these.
